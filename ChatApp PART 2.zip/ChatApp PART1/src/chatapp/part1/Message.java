/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package chatapp.part1;

import org.json.simple.JSONObject;
import java.util.ArrayList;
import java.util.Random;

public class Message {
    private static ArrayList<Message> sentMessages = new ArrayList<>();
    private static int totalMessages = 0;
    private String messageID;
    private String recipient;
    private String content;
    private String messageHash;
    private int messageNumber; // Store the message number for hash generation
    
    public Message(String recipient, String content) {
        this.recipient = recipient;
        this.content = content;
        this.messageID = generateMessageID();
        // Store current message number before creating hash
        this.messageNumber = totalMessages + 1;
        this.messageHash = createMessageHash();
    }
    
    // Generates unique 10-digit message ID
    private String generateMessageID() {
        Random rand = new Random();
        StringBuilder id = new StringBuilder();
        for (int i = 0; i < 10; i++) {
            id.append(rand.nextInt(10));
        }
        return id.toString();
    }
    
    /**
     * Validates that message ID is 10 digits or less
     * @return true if valid, false otherwise
     */
    public boolean checkMessageID() {
        return messageID != null && messageID.length() <= 10 && messageID.matches("\\d+");
    }
    
    /**
     * Validates that recipient number has international format
     * Must start with + and be 13 characters or less
     * @return true if valid, false otherwise
     */
    public boolean checkRecipientCell() {
        if (recipient == null || !recipient.startsWith("+")) {
            return false;
        }
        // Remove the + sign and check if remaining characters are digits
        String numberPart = recipient.substring(1);
        return numberPart.matches("\\d+") && recipient.length() <= 13;
    }
    
    /**
     * Creates message hash in format: XX:N:FIRSTLAST
     * XX = first 2 digits of message ID
     * N = message number
     * FIRSTLAST = first word + last word in uppercase
     * @return formatted message hash
     */
    public String createMessageHash() {
        if (content == null || content.trim().isEmpty()) {
            return messageID.substring(0, 2) + ":" + messageNumber + ":";
        }
        
        String[] words = content.trim().split("\\s+");
        String firstWord = words[0].toUpperCase();
        String lastWord = words[words.length - 1].toUpperCase();
        
        return messageID.substring(0, 2) + ":" + messageNumber + ":" + firstWord + lastWord;
    }
    
    /**
     * Processes message based on user action
     * @param action - "send", "store", or "disregard"
     * @return status message
     */
    public String SentMessage(String action) {
        if (action == null) {
            return "Invalid action.";
        }
        
        switch (action.toLowerCase().trim()) {
            case "send":
                sentMessages.add(this);
                totalMessages++;
                return "Message sent successfully!";
            case "store":
                // Store logic - message is prepared but not sent
                return "Message stored for later.";
            case "disregard":
                // Message is discarded
                return "Message disregarded.";
            default:
                return "Invalid action.";
        }
    }
    
    /**
     * Returns formatted string of all sent messages
     * @return string representation of all messages
     */
    public static String printMessages() {
        if (sentMessages.isEmpty()) {
            return "No messages sent yet.";
        }
        
        StringBuilder output = new StringBuilder();
        for (Message msg : sentMessages) {
            output.append("Recipient: ").append(msg.recipient)
                  .append("\nMessage: ").append(msg.content)
                  .append("\nHash: ").append(msg.messageHash)
                  .append("\nID: ").append(msg.messageID)
                  .append("\n-----------------\n");
        }
        return output.toString();
    }
    
    /**
     * Returns total number of messages sent
     * @return total message count
     */
    public static int returnTotalMessages() {
        return totalMessages;
    }
    
    /**
     * Converts message to JSON format
     * @return JSONObject containing message data
     */
    public JSONObject toJSON() {
        JSONObject obj = new JSONObject();
        obj.put("messageID", messageID);
        obj.put("recipient", recipient);
        obj.put("content", content);
        obj.put("messageHash", messageHash);
        obj.put("messageNumber", messageNumber);
        return obj;
    }
    
    /**
     * Resets static counters and lists (useful for testing)
     */
    public static void resetMessageData() {
        sentMessages.clear();
        totalMessages = 0;
    }
    
    // Getters
    public String getMessageHash() {
        return messageHash;
    }
    
    public String getRecipient() {
        return recipient;
    }
    
    public String getContent() {
        return content;
    }
    
    public String getMessageID() {
        return messageID;
    }
    
    public int getMessageNumber() {
        return messageNumber;
    }
    
    public static ArrayList<Message> getSentMessages() {
        return new ArrayList<>(sentMessages); // Return copy to prevent external modification
    }
}