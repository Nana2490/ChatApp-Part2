/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package chatapp.part1;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class MenuPanel extends JPanel {
    private MainGUI mainGUI;
    private String username;
    private MessageManager messageManager;

    private JLabel welcomeLabel;
    private JButton sendBtn, viewBtn, logoutBtn;
    private JPanel contentPanel;

    private final String[] countryCodes = {
            "+27 (South Africa)", "+1 (USA)", "+44 (UK)", "+61 (Australia)", "+49 (Germany)", "+33 (France)",
            "+39 (Italy)", "+81 (Japan)", "+82 (South Korea)", "+34 (Spain)", "+91 (India)", "+55 (Brazil)",
            "+7 (Russia)", "+86 (China)", "+46 (Sweden)", "+41 (Switzerland)", "+31 (Netherlands)", "+64 (New Zealand)",
            "+351 (Portugal)", "+48 (Poland)", "+65 (Singapore)", "+60 (Malaysia)", "+20 (Egypt)", "+234 (Nigeria)",
            "+966 (Saudi Arabia)", "+90 (Turkey)", "+352 (Luxembourg)", "+380 (Ukraine)", "+52 (Mexico)", "+98 (Iran)"
    };

    public MenuPanel(MainGUI mainGUI, String username, MessageManager messageManager) {
        this.mainGUI = mainGUI;
        this.username = username;
        this.messageManager = messageManager;
        initializeComponents();
        setupEventHandlers();
    }

    private void initializeComponents() {
        setLayout(null);
        setBackground(new Color(30, 0, 60));

        welcomeLabel = new JLabel("Welcome to QuickChatApp " + username + "!");
        welcomeLabel.setFont(new Font("Segoe UI", Font.BOLD, 22));
        welcomeLabel.setForeground(Color.WHITE);
        welcomeLabel.setBounds(40, 30, 400, 40);
        add(welcomeLabel);

        // Buttons
        sendBtn = new JButton("Send Message");
        viewBtn = new JButton("View Messages");
        logoutBtn = new JButton("Logout");

        styleButton(sendBtn);
        styleButton(viewBtn);
        styleButton(logoutBtn);

        // Arrange vertically (longitudinally) and numbered 1–3
        int startY = 90;
        int spacing = 50;

        JLabel sendLabel = new JLabel("1.");
        sendLabel.setForeground(Color.WHITE);
        sendLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        sendLabel.setBounds(40, startY + 5, 20, 30);
        add(sendLabel);

        sendBtn.setBounds(70, startY, 180, 35);
        add(sendBtn);

        JLabel viewLabel = new JLabel("2.");
        viewLabel.setForeground(Color.WHITE);
        viewLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        viewLabel.setBounds(40, startY + spacing + 5, 20, 30);
        add(viewLabel);

        viewBtn.setBounds(70, startY + spacing, 180, 35);
        add(viewBtn);

        JLabel logoutLabel = new JLabel("3.");
        logoutLabel.setForeground(Color.WHITE);
        logoutLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        logoutLabel.setBounds(40, startY + 2 * spacing + 5, 20, 30);
        add(logoutLabel);

        logoutBtn.setBounds(70, startY + 2 * spacing, 180, 35);
        add(logoutBtn);

        // Content panel
        contentPanel = new JPanel();
        contentPanel.setLayout(null);
        contentPanel.setBackground(new Color(45, 0, 80));
        contentPanel.setBounds(30, 250, 400, 340);
        add(contentPanel);
    }

    private void styleButton(JButton button) {
        button.setBackground(Color.WHITE);
        button.setForeground(new Color(30, 0, 60));
        button.setFocusPainted(false);
        button.setFont(new Font("Segoe UI", Font.BOLD, 13));
        button.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
    }

    private void setupEventHandlers() {
        sendBtn.addActionListener(e -> promptMessageCount());
        viewBtn.addActionListener(e -> promptMessageTypeSelection());
        logoutBtn.addActionListener(e -> {
            // Clear content panel on logout
            contentPanel.removeAll();
            contentPanel.revalidate();
            contentPanel.repaint();
            
            // Return to login panel (will clear fields there)
            mainGUI.showLoginPanel();
        });
    }

    private void promptMessageTypeSelection() {
        contentPanel.removeAll();

        JLabel title = new JLabel("Select Message Type to View:");
        title.setForeground(Color.WHITE);
        title.setFont(new Font("Segoe UI", Font.BOLD, 16));
        title.setBounds(20, 30, 350, 30);
        contentPanel.add(title);

        JButton viewSentBtn = new JButton("1. View Sent Messages");
        JButton viewStoredBtn = new JButton("2. View Stored Messages");

        styleButton(viewSentBtn);
        styleButton(viewStoredBtn);

        viewSentBtn.setBounds(70, 90, 250, 40);
        viewStoredBtn.setBounds(70, 150, 250, 40);

        contentPanel.add(viewSentBtn);
        contentPanel.add(viewStoredBtn);

        viewSentBtn.addActionListener(e -> showViewPanel("sent"));
        viewStoredBtn.addActionListener(e -> showViewPanel("stored"));

        contentPanel.revalidate();
        contentPanel.repaint();
    }

    private void promptMessageCount() {
        contentPanel.removeAll();

        JLabel countLabel = new JLabel("Enter number of messages to send:");
        countLabel.setForeground(Color.WHITE);
        countLabel.setBounds(20, 20, 250, 25);
        contentPanel.add(countLabel);

        JTextField countField = new JTextField();
        countField.setBounds(270, 20, 70, 25);
        contentPanel.add(countField);

        JButton startBtn = new JButton("Start");
        styleButton(startBtn);
        startBtn.setBounds(150, 60, 100, 30);
        contentPanel.add(startBtn);

        JLabel statusLabel = new JLabel("");
        statusLabel.setForeground(Color.WHITE);
        statusLabel.setBounds(20, 100, 350, 25);
        contentPanel.add(statusLabel);

        startBtn.addActionListener(e -> {
            String countText = countField.getText().trim();
            if (countText.isEmpty() || !countText.matches("\\d+")) {
                statusLabel.setForeground(Color.RED);
                statusLabel.setText("❌ Enter a valid number.");
                return;
            }
            int total = Integer.parseInt(countText);
            if (total <= 0) {
                statusLabel.setForeground(Color.RED);
                statusLabel.setText("❌ Number must be greater than 0.");
                return;
            }
            showMessageForm(total, 1);
        });

        contentPanel.revalidate();
        contentPanel.repaint();
    }

    private void showMessageForm(int totalMessages, int current) {
        contentPanel.removeAll();

        JLabel title = new JLabel("Message " + current + " of " + totalMessages);
        title.setForeground(Color.WHITE);
        title.setBounds(20, 10, 250, 25);
        contentPanel.add(title);

        JLabel phoneLabel = new JLabel("Recipient Phone:");
        phoneLabel.setForeground(Color.WHITE);
        phoneLabel.setBounds(20, 40, 150, 25);
        contentPanel.add(phoneLabel);

        JComboBox<String> countryCombo = new JComboBox<>(countryCodes);
        countryCombo.setBounds(20, 70, 150, 30);
        contentPanel.add(countryCombo);

        JTextField phoneField = new JTextField();
        phoneField.setBounds(180, 70, 180, 30);
        contentPanel.add(phoneField);

        JLabel msgLabel = new JLabel("Message (max 250 chars):");
        msgLabel.setForeground(Color.WHITE);
        msgLabel.setBounds(20, 110, 200, 25);
        contentPanel.add(msgLabel);

        JTextArea msgArea = new JTextArea();
        msgArea.setLineWrap(true);
        JScrollPane scrollPane = new JScrollPane(msgArea);
        scrollPane.setBounds(20, 140, 340, 120);
        contentPanel.add(scrollPane);

        JButton sendBtn = new JButton("Send");
        JButton storeBtn = new JButton("Store");
        JButton deleteBtn = new JButton("Disregard");

        // Styled buttons
        styleButton(sendBtn);
        styleButton(storeBtn);
        styleButton(deleteBtn);

        sendBtn.setBounds(40, 270, 100, 30);
        storeBtn.setBounds(150, 270, 100, 30);
        deleteBtn.setBounds(260, 270, 100, 30);

        contentPanel.add(sendBtn);
        contentPanel.add(storeBtn);
        contentPanel.add(deleteBtn);

        JLabel statusLabel = new JLabel("");
        statusLabel.setForeground(Color.WHITE);
        statusLabel.setBounds(20, 305, 360, 25);
        contentPanel.add(statusLabel);

        ActionListener nextMessage = e -> {
            if (current < totalMessages) {
                showMessageForm(totalMessages, current + 1);
            } else {
                statusLabel.setText("All messages processed.");
            }
        };

        sendBtn.addActionListener(e -> {
            String country = (String) countryCombo.getSelectedItem();
            String number = phoneField.getText().trim();
            String content = msgArea.getText().trim();

            // Validate phone number
            if (!number.matches("\\d{10}")) {
                statusLabel.setForeground(Color.RED);
                statusLabel.setText("❌ Enter a valid 10-digit phone number.");
                return;
            }

            if (content.isEmpty()) {
                statusLabel.setForeground(Color.RED);
                statusLabel.setText("❌ Message cannot be empty.");
                return;
            }

            messageManager.addMessage(username, country.split(" ")[0] + number, content);
            statusLabel.setForeground(new Color(0, 255, 100));
            statusLabel.setText("✅ Message sent!");
            nextMessage.actionPerformed(null);
        });

        storeBtn.addActionListener(e -> {
            String country = (String) countryCombo.getSelectedItem();
            String number = phoneField.getText().trim();
            String content = msgArea.getText().trim();

            if (!number.matches("\\d{10}")) {
                statusLabel.setForeground(Color.RED);
                statusLabel.setText("❌ Enter a valid 10-digit phone number.");
                return;
            }

            if (content.isEmpty()) {
                statusLabel.setForeground(Color.RED);
                statusLabel.setText("❌ Message cannot be empty.");
                return;
            }

            messageManager.storeMessage(username, country.split(" ")[0] + number, content);
            statusLabel.setForeground(new Color(0, 255, 200));
            statusLabel.setText("💾 Message stored!");
            nextMessage.actionPerformed(null);
        });

        deleteBtn.addActionListener(e -> {
            int confirm = JOptionPane.showConfirmDialog(
                    this,
                    "Do you want to continue sending messages?",
                    "Confirm Disregard",
                    JOptionPane.YES_NO_OPTION
            );

            if (confirm == JOptionPane.YES_OPTION) {
                msgArea.setText("");
                phoneField.setText("");
                statusLabel.setText("🗑 Message cleared. Continue sending...");
            } else {
                contentPanel.removeAll();
                contentPanel.revalidate();
                contentPanel.repaint();
            }
        });

        contentPanel.revalidate();
        contentPanel.repaint();
    }

    private void showViewPanel(String messageType) {
        contentPanel.removeAll();

        String titleText = messageType.equals("sent") ? "Sent Messages" : "Stored Messages";
        JLabel title = new JLabel(titleText);
        title.setForeground(Color.WHITE);
        title.setFont(new Font("Segoe UI", Font.BOLD, 16));
        title.setBounds(20, 20, 250, 25);
        contentPanel.add(title);

        String messages = messageType.equals("sent") ? 
            messageManager.getSentMessages() : 
            messageManager.getStoredMessages();

        JTextArea msgDisplay = new JTextArea(messages);
        msgDisplay.setEditable(false);
        msgDisplay.setLineWrap(true);
        msgDisplay.setWrapStyleWord(true);
        msgDisplay.setFont(new Font("Monospaced", Font.PLAIN, 12));
        msgDisplay.setBackground(new Color(240, 240, 240));
        JScrollPane scrollPane = new JScrollPane(msgDisplay);
        scrollPane.setBounds(20, 50, 340, 220);
        contentPanel.add(scrollPane);

        JButton backBtn = new JButton("Back");
        styleButton(backBtn);
        backBtn.setBounds(140, 280, 100, 30);
        backBtn.addActionListener(e -> promptMessageTypeSelection());
        contentPanel.add(backBtn);

        contentPanel.revalidate();
        contentPanel.repaint();
    }
}