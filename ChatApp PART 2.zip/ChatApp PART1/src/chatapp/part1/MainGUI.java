/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package chatapp.part1;

/**
 *
 * @author ST10479313
 */
import javax.swing.*;
import java.awt.*;

public class MainGUI extends JFrame {
    private LoginPanel loginPanel;
    private Register registerPanel;
    private MenuPanel menuPanel;
    private MessageManager messageManager;

    public MainGUI() {
        setTitle("QuickChat");
        setSize(480, 650);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new CardLayout());

        messageManager = new MessageManager();

        // Initialize panels
        loginPanel = new LoginPanel(this);
        registerPanel = new Register(this);

        //  Add Welcome panel first
        WelcomePanel welcomePanel = new WelcomePanel(this);
        add(welcomePanel, "Welcome");
        add(loginPanel, "Login");
        add(registerPanel, "Register");

        // Show Welcome screen first
        ((CardLayout) getContentPane().getLayout()).show(getContentPane(), "Welcome");

        setVisible(true);
    }

    public void showLoginPanel() {
        ((CardLayout) getContentPane().getLayout()).show(getContentPane(), "Login");
        if (menuPanel != null) {
            remove(menuPanel); // Clean up if switching back
            menuPanel = null;
    loginPanel.clearFields(); // Clear fields and status message
        }
    }

    public void showRegisterPanel() {
        ((CardLayout) getContentPane().getLayout()).show(getContentPane(), "Register");
    }

    public void showMenuPanel(String username) {
        menuPanel = new MenuPanel(this, username, messageManager);
        add(menuPanel, "Menu");
        ((CardLayout) getContentPane().getLayout()).show(getContentPane(), "Menu");
    }

    public MessageManager getMessageManager() {
        return messageManager;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(MainGUI::new);
    }

    private static class cardLayout {

        public cardLayout() {
        }
    }
}
