/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package chatapp.part1;

/**
 *
 * @author ST10479313
 */

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Register extends JPanel {
    private MainGUI mainGUI;
    private JTextField firstNameField;
    private JTextField lastNameField;
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JTextField phoneField;
    private JButton registerBtn;
    private JButton backToLoginBtn;
    private JLabel statusLabel;

    public Register(MainGUI mainGUI) {
        this.mainGUI = mainGUI;
        initializeComponents();
        setupLayout();
        setupEventHandlers();
    }

    private void initializeComponents() {
        setLayout(null);
        setBackground(new Color(30, 0, 60)); // Purple background

        // Header
        JLabel headerLabel = new JLabel("Register");
        headerLabel.setFont(new Font("Segoe UI", Font.BOLD, 28));
        headerLabel.setForeground(Color.WHITE);
        headerLabel.setBounds(140, 20, 150, 40);
        add(headerLabel);

        // First Name
        JLabel firstNameLabel = new JLabel("First Name:");
        firstNameLabel.setForeground(Color.LIGHT_GRAY);
        firstNameLabel.setBounds(100, 70, 100, 20);
        add(firstNameLabel);
        
        firstNameField = new JTextField();
        styleTextField(firstNameField);
        firstNameField.setBounds(100, 95, 200, 30);
        add(firstNameField);

        // Last Name
        JLabel lastNameLabel = new JLabel("Last Name:");
        lastNameLabel.setForeground(Color.LIGHT_GRAY);
        lastNameLabel.setBounds(100, 135, 100, 20);
        add(lastNameLabel);
        
        lastNameField = new JTextField();
        styleTextField(lastNameField);
        lastNameField.setBounds(100, 160, 200, 30);
        add(lastNameField);

        // Username
        JLabel usernameLabel = new JLabel("Username:");
        usernameLabel.setForeground(Color.LIGHT_GRAY);
        usernameLabel.setBounds(100, 200, 100, 20);
        add(usernameLabel);
        
        usernameField = new JTextField();
        styleTextField(usernameField);
        usernameField.setBounds(100, 225, 200, 30);
        add(usernameField);

        // Password
        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setForeground(Color.LIGHT_GRAY);
        passwordLabel.setBounds(100, 265, 100, 20);
        add(passwordLabel);
        
        passwordField = new JPasswordField();
        styleTextField(passwordField);
        passwordField.setBounds(100, 290, 200, 30);
        add(passwordField);

        // Phone Number
        JLabel phoneLabel = new JLabel("SA Phone (+27...):");
        phoneLabel.setForeground(Color.LIGHT_GRAY);
        phoneLabel.setBounds(100, 330, 150, 20);
        add(phoneLabel);
        
        phoneField = new JTextField();
        styleTextField(phoneField);
        phoneField.setBounds(100, 355, 200, 30);
        add(phoneField);

        // Register Button
        registerBtn = new JButton("Register");
        styleButton(registerBtn);
        registerBtn.setBounds(150, 400, 100, 35);
        add(registerBtn);

        // Back to Login Button
        backToLoginBtn = new JButton("Back to Login");
        styleButton(backToLoginBtn);
        backToLoginBtn.setBounds(120, 445, 160, 30);
        add(backToLoginBtn);

        // Status Label
        statusLabel = new JLabel("", SwingConstants.CENTER);
        statusLabel.setBounds(20, 480, 360, 60);
        statusLabel.setFont(new Font("Segoe UI", Font.BOLD, 13)); // Bold and thick
        statusLabel.setHorizontalAlignment(SwingConstants.CENTER);
        add(statusLabel);
    }

    private void styleTextField(JTextField field) {
        field.setBackground(new Color(200, 200, 200)); // Light grey
        field.setForeground(Color.BLACK);
        field.setBorder(BorderFactory.createLineBorder(new Color(100, 0, 150), 2));
        field.setFont(new Font("Segoe UI", Font.PLAIN, 14));
    }

    private void styleButton(JButton button) {
        button.setBackground(new Color(255, 255, 255));
        button.setForeground(Color.BLACK);
        button.setFocusPainted(false);
        button.setFont(new Font("Segoe UI", Font.BOLD, 14));
        button.setBorder(BorderFactory.createEmptyBorder(8, 15, 8, 15));
    }

    private void setupLayout() {
        // Layout is handled in initializeComponents with setBounds
    }

    private void setupEventHandlers() {
        registerBtn.addActionListener(e -> handleRegistration());
        backToLoginBtn.addActionListener(e -> mainGUI.showLoginPanel());
    }

    private void handleRegistration() {
        String firstName = firstNameField.getText().trim();
        String lastName = lastNameField.getText().trim();
        String username = usernameField.getText().trim();
        String password = new String(passwordField.getPassword());
        String phone = phoneField.getText().trim();

        //  All fields must be filled
        if (firstName.isEmpty() || lastName.isEmpty() || username.isEmpty() || password.isEmpty() || phone.isEmpty()) {
            statusLabel.setForeground(Color.RED);
            statusLabel.setText("All fields must be filled in to complete registration.");
            return;
        }

        // New Validation: Username rules
        if (!username.matches("^[a-z_]{5}$") || !username.contains("_")) {
            statusLabel.setForeground(Color.RED);
            statusLabel.setText("Username: 5 lowercase letters" + " and include underscore (_).");
            return;
        }

        Login login = Login.getInstance();
        String result = login.registerUser(firstName, lastName, username, password, phone);

        if (result.contains("successfully")) {
            statusLabel.setForeground(new Color(0, 255, 100)); // Green for success
            clearFields();
        } else {
            statusLabel.setForeground(Color.RED); // Red for error
        }

        statusLabel.setText("<html><div style='text-align: center;'>" + result.replace("\n", "<br>") + "</div></html>");
    }

    private void clearFields() {
        firstNameField.setText("");
        lastNameField.setText("");
        usernameField.setText("");
        passwordField.setText("");
        phoneField.setText("");
    }
}
