/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package chatapp.part1;

import javax.swing.*;
import java.awt.*;

public class WelcomePanel extends JPanel {

    public WelcomePanel(MainGUI mainGUI) {
        setLayout(new BorderLayout());
        setBackground(new Color(30, 0, 60));

        JLabel welcomeLabel = new JLabel("Welcome to QuickChat", SwingConstants.CENTER);
        welcomeLabel.setFont(new Font("Segoe UI", Font.BOLD, 32));
        welcomeLabel.setForeground(Color.WHITE);
        add(welcomeLabel, BorderLayout.CENTER);

        // Use a timer to move to the login screen after 3 seconds
        Timer timer = new Timer(3000, e -> mainGUI.showLoginPanel());
        timer.setRepeats(false);
        timer.start();
    }
}
