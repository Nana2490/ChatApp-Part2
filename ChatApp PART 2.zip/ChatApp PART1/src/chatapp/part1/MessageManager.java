/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package chatapp.part1;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.core.type.TypeReference;

import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

    // List to hold sent and stored messages
public class MessageManager {
    private ArrayList<MessageRecord> sentMessages = new ArrayList<>();
    private ArrayList<MessageRecord> storedMessages = new ArrayList<>();
    private int messageCounter = 0;

    private final String SENT_FILE = "sentMessages.json";
    private final String STORED_FILE = "storedMessages.json";

    private static class MessageRecord {
        public String messageID;
        public String messageHash;
        public String sender;
        public String recipient;
        public String content;
        public String timestamp;

        public MessageRecord() {} // Default constructor for Jackson

        public MessageRecord(String messageID, String messageHash, String sender,
                             String recipient, String content, String timestamp) {
            this.messageID = messageID;
            this.messageHash = messageHash;
            this.sender = sender;
            this.recipient = recipient;
            this.content = content;
            this.timestamp = timestamp;
        }
        

        @Override
        public String toString() {
            return "ID: " + messageID +
                    "\nHASH: " + messageHash +
                    "\nTO: " + recipient +
                    "\nMESSAGE: " + content +
                    "\nTIME: " + timestamp;
        }
    }

    private String generateMessageID() {
        messageCounter++;
        return String.format("%010d", messageCounter);
    }

    private String generateMessageHash(String messageID, String content) {
        String[] words = content.trim().split("\\s+");
        String firstWord = words.length > 0 ? words[0] : "";
        String lastWord = words.length > 1 ? words[words.length - 1] : firstWord;
        return (messageID.substring(0, 2) + ":" + messageCounter + ":" + (firstWord + lastWord)).toUpperCase();
    }

    private String getCurrentTimestamp() {
        return LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"));
    }

    private void saveToJson(String filename, ArrayList<MessageRecord> messages) {
        ObjectMapper mapper = new ObjectMapper().enable(SerializationFeature.INDENT_OUTPUT);
        try {
            mapper.writeValue(new File(filename), messages);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private ArrayList<MessageRecord> loadFromJson(String filename) {
        ObjectMapper mapper = new ObjectMapper();
        try {
            File file = new File(filename);
            if (file.exists()) {
                return mapper.readValue(file, new TypeReference<ArrayList<MessageRecord>>() {});
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return new ArrayList<>();
    }

    public MessageManager() {
        // Load existing messages from JSON on startup
        sentMessages = loadFromJson(SENT_FILE);
        storedMessages = loadFromJson(STORED_FILE);

        // Ensure messageCounter continues correctly
        int maxID = 0;
        for (MessageRecord m : sentMessages) maxID = Math.max(maxID, Integer.parseInt(m.messageID));
        for (MessageRecord m : storedMessages) maxID = Math.max(maxID, Integer.parseInt(m.messageID));
        messageCounter = maxID;
    }

    public void addMessage(String sender, String recipient, String content) {
        String messageID = generateMessageID();
        String hash = generateMessageHash(messageID, content);
        String timestamp = getCurrentTimestamp();
        MessageRecord record = new MessageRecord(messageID, hash, sender, recipient, content, timestamp);
        sentMessages.add(record);
        saveToJson(SENT_FILE, sentMessages); // Save to JSON immediately
    }

    public void storeMessage(String sender, String recipient, String content) {
        String messageID = generateMessageID();
        String hash = generateMessageHash(messageID, content);
        String timestamp = getCurrentTimestamp();
        MessageRecord record = new MessageRecord(messageID, hash, sender, recipient, content, timestamp);
        storedMessages.add(record);
        saveToJson(STORED_FILE, storedMessages); // Save to JSON immediately
    }
    
// Returns a string representation of all messages (sent and stored)
    public String getAllMessages() {
        StringBuilder sb = new StringBuilder();
        if (!sentMessages.isEmpty()) {
            sb.append("=== Sent Messages ===\n");
            for (MessageRecord msg : sentMessages) {
                sb.append(msg.toString()).append("\n------------------\n");
            }
        }
        if (!storedMessages.isEmpty()) {
            sb.append("=== Stored Messages ===\n");
            for (MessageRecord msg : storedMessages) {
                sb.append(msg.toString()).append("\n------------------\n");
            }
        }
        if (sb.length() == 0) return "No messages yet.";
        return sb.toString();
    }
    
// Returns a string of only sent messages
    public String getSentMessages() {
        if (sentMessages.isEmpty()) {
            return "No sent messages yet.";
        }
        StringBuilder sb = new StringBuilder();
        for (MessageRecord msg : sentMessages) {
            sb.append(msg.toString()).append("\n------------------\n");
        }
        return sb.toString();
    }

    public String getStoredMessages() {
        if (storedMessages.isEmpty()) {
            return "No stored messages yet.";
        }
        StringBuilder sb = new StringBuilder();
        for (MessageRecord msg : storedMessages) {
            sb.append(msg.toString()).append("\n------------------\n");
        }
        return sb.toString();
    }

    public int getTotalMessagesSent() {
        return sentMessages.size();
    }
}