/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package chatapp.part1;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Login {
    private static Login instance;
    private String storedFirstName;
    private String storedLastName;
    private String storedUsername;
    private String storedPassword;
    private String storedPhone;

    public Login() {
        // Private constructor for singleton pattern
    }

    public static Login getInstance() {
        if (instance == null) {
            instance = new Login();
        }
        return instance;
    }

    // Method to check if username contains underscore and is no more than 5 characters
    public boolean checkUserName(String username) {
        if (username == null || username.isEmpty()) {
            return false;
        }
        return username.contains("_") && username.length() <= 5;
    }

    // Method to check password complexity
    public boolean checkPasswordComplexity(String password) {
        if (password == null || password.length() < 8) {
            return false;
        }
        
        boolean hasUpper = false;
        boolean hasDigit = false;
        boolean hasSpecial = false;
        
        for (char c : password.toCharArray()) {
            if (Character.isUpperCase(c)) {
                hasUpper = true;
            } else if (Character.isDigit(c)) {
                hasDigit = true;
            } else if (!Character.isLetterOrDigit(c)) {
                hasSpecial = true;
            }
        }
        
        return hasUpper && hasDigit && hasSpecial;
    }

    // Method to check South African cell phone number
    public boolean checkCellPhoneNumber(String cellPhoneNumber) {
        if (cellPhoneNumber == null) {
            return false;
        }
        // Must contain international country code and be no more than 10 characters after code
        return cellPhoneNumber.matches("^\\+27\\d{9}$");
    }

    // Method to register user
    public String registerUser(String firstName, String lastName, String username, String password, String phone) {
        if (!checkUserName(username)) {
            return "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length.";
        }
        
        if (!checkPasswordComplexity(password)) {
            return "Password is not correctly formatted, please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
        }
        
        if (!checkCellPhoneNumber(phone)) {
            return "Cell number is incorrectly formatted or does not contain international code, please correct the number and try again.";
        }

        // This stores user data
        this.storedFirstName = firstName;
        this.storedLastName = lastName;
        this.storedUsername = username;
        this.storedPassword = password;
        this.storedPhone = phone;

        return "Username successfully captured.\nPassword successfully captured.\nCell phone number successfully added.";
    }

    // Method to verify login credentials
    public boolean loginUser(String username, String password) {
        if (storedUsername == null || storedPassword == null) {
            return false;
        }
        return storedUsername.equals(username) && storedPassword.equals(password);
    }

    // Method to return login status message
    public String returnLoginStatus() {
        if (storedFirstName != null && storedLastName != null) {
            return "Welcome " + storedFirstName + " " + storedLastName + ", it's great to see you again!!";
        }
        return "";
    }
}
