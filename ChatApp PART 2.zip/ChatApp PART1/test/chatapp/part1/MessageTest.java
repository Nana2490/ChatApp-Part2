package chatapp.part1;

import org.json.simple.JSONObject;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * Complete JUnit Test Suite for Message Class
 * @author RC_Student_Lab
 */
public class MessageTest {
    
    private Message testMessage1;
    private Message testMessage2;
    
    public MessageTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
        System.out.println("Starting Message Test Suite...");
        System.out.println("================================");
    }
    
    @AfterClass
    public static void tearDownClass() {
        System.out.println("================================");
        System.out.println("Test Suite Completed!");
        // Final cleanup
        Message.resetMessageData();
    }
    
    @Before
    public void setUp() {
        // Reset static data before each test to ensure independence
        Message.resetMessageData();
        
        // Create test messages before each test
        testMessage1 = new Message("+27718693002", "Hi Mike can you join us for dinner tonight");
        testMessage2 = new Message("+27857597588", "Hi Keegan did you receive the payment");
    }
    
    @After
    public void tearDown() {
        testMessage1 = null;
        testMessage2 = null;
    }

    /**
     * Test of checkMessageID method - validates 10-digit ID
     */
    @Test
    public void testCheckMessageID_Valid() {
        System.out.println("Testing checkMessageID - Valid ID...");
        boolean result = testMessage1.checkMessageID();
        assertTrue("Message ID should be valid (10 digits or less)", result);
        
        // Verify the ID is exactly 10 digits
        assertEquals("Message ID should be 10 digits", 10, testMessage1.getMessageID().length());
        
        // Verify it contains only digits
        assertTrue("Message ID should contain only digits", 
                   testMessage1.getMessageID().matches("\\d{10}"));
    }
    
    /**
     * Test message ID for second message
     */
    @Test
    public void testCheckMessageID_MultipleMessages() {
        System.out.println("Testing checkMessageID - Multiple messages...");
        
        assertTrue("First message ID should be valid", testMessage1.checkMessageID());
        assertTrue("Second message ID should be valid", testMessage2.checkMessageID());
        
        // IDs should be different (highly unlikely to be same with random generation)
        assertNotEquals("Message IDs should be unique", 
                       testMessage1.getMessageID(), testMessage2.getMessageID());
    }

    /**
     * Test of checkRecipientCell method - validates international format with + prefix
     */
    @Test
    public void testCheckRecipientCell_ValidFormat() {
        System.out.println("Testing checkRecipientCell - Valid format...");
        
        // Valid international format with + prefix
        boolean result1 = testMessage1.checkRecipientCell();
        assertTrue("Recipient cell with + prefix should be valid", result1);
        
        boolean result2 = testMessage2.checkRecipientCell();
        assertTrue("Second recipient cell should also be valid", result2);
    }
    
    /**
     * Test recipient cell validation - invalid format without + prefix
     */
    @Test
    public void testCheckRecipientCell_InvalidFormat() {
        System.out.println("Testing checkRecipientCell - Invalid format...");
        
        // Invalid format (no + prefix)
        Message invalidMessage = new Message("0857597588", "Test message");
        boolean result = invalidMessage.checkRecipientCell();
        assertFalse("Recipient cell without + prefix should be invalid", result);
    }
    
    /**
     * Test recipient cell validation - various invalid formats
     */
    @Test
    public void testCheckRecipientCell_VariousInvalidFormats() {
        System.out.println("Testing checkRecipientCell - Various invalid formats...");
        
        // Too long (more than 13 characters)
        Message msg1 = new Message("+271234567890123", "Test");
        assertFalse("Number longer than 13 chars should be invalid", msg1.checkRecipientCell());
        
        // Contains letters
        Message msg2 = new Message("+27ABC1234567", "Test");
        assertFalse("Number with letters should be invalid", msg2.checkRecipientCell());
        
        // Missing + but has correct length
        Message msg3 = new Message("27718693002", "Test");
        assertFalse("Number without + should be invalid", msg3.checkRecipientCell());
    }

    /**
     * Test of createMessageHash method - validates hash format XX:N:FIRSTLAST
     */
    @Test
    public void testCreateMessageHash_Format() {
        System.out.println("Testing createMessageHash - Format validation...");
        
        String hash = testMessage1.createMessageHash();
        assertNotNull("Message hash should not be null", hash);
        
        // Verify hash contains the required components
        assertTrue("Hash should contain colons", hash.contains(":"));
        
        // Check format: should have first 2 digits of ID, message number, FIRSTLAST
        String[] parts = hash.split(":");
        assertEquals("Hash should have 3 parts separated by colons", 3, parts.length);
        
        // Part 0: First 2 digits of message ID
        assertEquals("First part should be 2 digits", 2, parts[0].length());
        assertTrue("First part should be digits", parts[0].matches("\\d{2}"));
        
        // Part 1: Message number
        assertTrue("Second part should be a number", parts[1].matches("\\d+"));
        
        // Part 2: FIRSTLAST in uppercase
        assertTrue("Last part should be uppercase", parts[2].equals(parts[2].toUpperCase()));
    }
    
    /**
     * Test hash content - verify first and last words
     */
    @Test
    public void testCreateMessageHash_WordExtraction() {
        System.out.println("Testing createMessageHash - Word extraction...");
        
        String hash1 = testMessage1.createMessageHash();
        // Message: "Hi Mike can you join us for dinner tonight"
        // First word: HI, Last word: TONIGHT
        assertTrue("Hash should contain first and last words", 
                   hash1.toUpperCase().contains("HITONIGHT"));
        
        String hash2 = testMessage2.createMessageHash();
        // Message: "Hi Keegan did you receive the payment"
        // First word: HI, Last word: PAYMENT
        assertTrue("Hash should contain first and last words", 
                   hash2.toUpperCase().contains("HIPAYMENT"));
    }
    
    /**
     * Test hash with single word message
     */
    @Test
    public void testCreateMessageHash_SingleWord() {
        System.out.println("Testing createMessageHash - Single word...");
        
        Message singleWord = new Message("+27718693002", "Hello");
        String hash = singleWord.createMessageHash();
        
        // Single word should appear twice (as first and last)
        assertTrue("Single word should be duplicated in hash", 
                   hash.contains("HELLOHELLO"));
    }

    /**
     * Test of SentMessage method - tests Send action
     */
    @Test
    public void testSentMessage_Send() {
        System.out.println("Testing SentMessage - Send action...");
        
        int initialCount = Message.returnTotalMessages();
        String result = testMessage1.SentMessage("send");
        
        assertEquals("Send action should return success message", 
                     "Message sent successfully!", result);
        assertEquals("Total messages should increment by 1", 
                     initialCount + 1, Message.returnTotalMessages());
    }
    
    /**
     * Test sending multiple messages
     */
    @Test
    public void testSentMessage_SendMultiple() {
        System.out.println("Testing SentMessage - Multiple sends...");
        
        testMessage1.SentMessage("send");
        testMessage2.SentMessage("send");
        
        assertEquals("Should have 2 sent messages", 2, Message.returnTotalMessages());
    }
    
    /**
     * Test of SentMessage method - tests Store action
     */
    @Test
    public void testSentMessage_Store() {
        System.out.println("Testing SentMessage - Store action...");
        
        int initialCount = Message.returnTotalMessages();
        String result = testMessage2.SentMessage("store");
        
        assertEquals("Store action should return correct message", 
                     "Message stored for later.", result);
        
        // Storing should NOT increment total messages
        assertEquals("Total messages should not change on store", 
                     initialCount, Message.returnTotalMessages());
    }
    
    /**
     * Test of SentMessage method - tests Disregard action
     */
    @Test
    public void testSentMessage_Disregard() {
        System.out.println("Testing SentMessage - Disregard action...");
        
        int initialCount = Message.returnTotalMessages();
        String result = testMessage2.SentMessage("disregard");
        
        assertEquals("Disregard action should return correct message", 
                     "Message disregarded.", result);
        
        // Disregarding should NOT increment total messages
        assertEquals("Total messages should not change on disregard", 
                     initialCount, Message.returnTotalMessages());
    }
    
    /**
     * Test of SentMessage method - tests invalid action
     */
    @Test
    public void testSentMessage_InvalidAction() {
        System.out.println("Testing SentMessage - Invalid action...");
        
        String result = testMessage1.SentMessage("invalid");
        assertEquals("Invalid action should return error message", 
                     "Invalid action.", result);
        
        // Should not affect message count
        assertEquals("Invalid action should not change message count", 
                     0, Message.returnTotalMessages());
    }
    
    /**
     * Test case insensitivity of actions
     */
    @Test
    public void testSentMessage_CaseInsensitive() {
        System.out.println("Testing SentMessage - Case insensitivity...");
        
        String result1 = testMessage1.SentMessage("SEND");
        assertEquals("Uppercase SEND should work", "Message sent successfully!", result1);
        
        Message msg = new Message("+27718693002", "Test");
        String result2 = msg.SentMessage("StOrE");
        assertEquals("Mixed case should work", "Message stored for later.", result2);
    }

    /**
     * Test of printMessages method - with messages
     */
    @Test
    public void testPrintMessages_WithMessages() {
        System.out.println("Testing printMessages - With sent messages...");
        
        // Send messages first
        testMessage1.SentMessage("send");
        testMessage2.SentMessage("send");
        
        String result = Message.printMessages();
        assertNotNull("Print messages should not return null", result);
        
        assertTrue("Should contain recipient information", 
                   result.contains("Recipient:"));
        assertTrue("Should contain message content", 
                   result.contains("Message:"));
        assertTrue("Should contain hash", 
                   result.contains("Hash:"));
        assertTrue("Should contain first message recipient", 
                   result.contains("+27718693002"));
        assertTrue("Should contain second message recipient", 
                   result.contains("+27857597588"));
    }
    
    /**
     * Test printMessages with no messages sent
     */
    @Test
    public void testPrintMessages_NoMessages() {
        System.out.println("Testing printMessages - No messages...");
        
        String result = Message.printMessages();
        assertEquals("Should return 'no messages' text when empty", 
                    "No messages sent yet.", result);
    }

    /**
     * Test of returnTotalMessages method - initial state
     */
    @Test
    public void testReturnTotalMessages_Initial() {
        System.out.println("Testing returnTotalMessages - Initial state...");
        
        // After reset, should be 0
        int count = Message.returnTotalMessages();
        assertEquals("Initial message count should be 0", 0, count);
    }
    
    /**
     * Test of returnTotalMessages method - after sending
     */
    @Test
    public void testReturnTotalMessages_AfterSending() {
        System.out.println("Testing returnTotalMessages - After sending...");
        
        int initialCount = Message.returnTotalMessages();
        
        testMessage1.SentMessage("send");
        testMessage2.SentMessage("send");
        
        int newCount = Message.returnTotalMessages();
        assertEquals("Total messages should increase by 2", 
                     initialCount + 2, newCount);
    }
    
    /**
     * Test that store and disregard don't affect total
     */
    @Test
    public void testReturnTotalMessages_StoreAndDisregardNoEffect() {
        System.out.println("Testing returnTotalMessages - Store/Disregard no effect...");
        
        testMessage1.SentMessage("store");
        testMessage2.SentMessage("disregard");
        
        assertEquals("Store and disregard should not affect total", 
                     0, Message.returnTotalMessages());
    }

    /**
     * Test of toJSON method - structure validation
     */
    @Test
    public void testToJSON_Structure() {
        System.out.println("Testing toJSON - Structure...");
        
        JSONObject result = testMessage1.toJSON();
        assertNotNull("JSON object should not be null", result);
        
        // Verify all required keys are present
        assertTrue("JSON should contain messageID", result.containsKey("messageID"));
        assertTrue("JSON should contain recipient", result.containsKey("recipient"));
        assertTrue("JSON should contain content", result.containsKey("content"));
        assertTrue("JSON should contain messageHash", result.containsKey("messageHash"));
    }
    
    /**
     * Test toJSON content accuracy
     */
    @Test
    public void testToJSON_ContentAccuracy() {
        System.out.println("Testing toJSON - Content accuracy...");
        
        JSONObject result = testMessage1.toJSON();
        
        assertEquals("Recipient should match", 
                     testMessage1.getRecipient(), result.get("recipient"));
        assertEquals("Content should match", 
                     testMessage1.getContent(), result.get("content"));
        assertEquals("Message ID should match", 
                     testMessage1.getMessageID(), result.get("messageID"));
        assertEquals("Message hash should match", 
                     testMessage1.getMessageHash(), result.get("messageHash"));
    }

    /**
     * Test of getMessageHash method
     */
    @Test
    public void testGetMessageHash() {
        System.out.println("Testing getMessageHash...");
        
        String result = testMessage1.getMessageHash();
        assertNotNull("Message hash should not be null", result);
        assertFalse("Message hash should not be empty", result.isEmpty());
        
        // Should contain colons
        assertTrue("Hash should contain colons", result.contains(":"));
    }

    /**
     * Test of getRecipient method
     */
    @Test
    public void testGetRecipient() {
        System.out.println("Testing getRecipient...");
        
        String result1 = testMessage1.getRecipient();
        assertEquals("Should return correct recipient", "+27718693002", result1);
        
        String result2 = testMessage2.getRecipient();
        assertEquals("Should return correct recipient", "+27857597588", result2);
    }

    /**
     * Test of getContent method
     */
    @Test
    public void testGetContent() {
        System.out.println("Testing getContent...");
        
        String result = testMessage1.getContent();
        assertEquals("Should return correct content", 
                     "Hi Mike can you join us for dinner tonight", result);
        
        String result2 = testMessage2.getContent();
        assertEquals("Should return correct content",
                     "Hi Keegan did you receive the payment", result2);
    }

    /**
     * Test of getMessageID method
     */
    @Test
    public void testGetMessageID() {
        System.out.println("Testing getMessageID...");
        
        String result = testMessage1.getMessageID();
        assertNotNull("Message ID should not be null", result);
        assertEquals("Message ID should be 10 digits", 10, result.length());
        assertTrue("Message ID should contain only digits", result.matches("\\d{10}"));
    }
    
    /**
     * Integration test - complete message lifecycle
     */
    @Test
    public void testCompleteMessageLifecycle() {
        System.out.println("Testing complete message lifecycle...");
        
        // Create message
        Message msg = new Message("+27718693002", "Complete lifecycle test");
        
        // Validate
        assertTrue("Message should have valid ID", msg.checkMessageID());
        assertTrue("Message should have valid recipient", msg.checkRecipientCell());
        assertNotNull("Message should have hash", msg.getMessageHash());
        
        // Send
        String sendResult = msg.SentMessage("send");
        assertEquals("Should send successfully", "Message sent successfully!", sendResult);
        
        // Verify it appears in print
        String printResult = Message.printMessages();
        assertTrue("Should appear in printed messages", 
                   printResult.contains("Complete lifecycle test"));
        
        // Verify count
        assertEquals("Total should be 1", 1, Message.returnTotalMessages());
        
        // Verify JSON
        JSONObject json = msg.toJSON();
        assertEquals("JSON should have correct content", 
                     "Complete lifecycle test", json.get("content"));
    }
}